/**** Package Information  ****/

1. This package contains one Lightnig web component
2. Apex classes 2.
3. Lightning web component enabled to use on home screen and record pages.
4. Install in any scratch org and can run the program.
5. No Profile permission is included.
6. No objects or fields included.