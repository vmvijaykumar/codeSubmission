import { LightningElement, track, wire } from 'lwc';
import handleMove from '@salesforce/apex/RobotController.handleMove';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Robot extends LightningElement {
    @track placed ='false';
    @track Facingvalue = '--None--';
    @track newFacingValue;
    @track xvalue=0;
    @track yvalue=0;
    @track newPosition;
    get options() {
        return [
                 { label: '--None--', value: '--None--' },
                 { label: 'East', value: 'East' },
                 { label: 'West', value: 'West' },
                 { label: 'North', value: 'North' },
                 { label: 'South', value: 'South' },
               ];
    }
   
    onValueChange(event){//set face value on change
        this.Facingvalue = event.detail.value;
        this.newFacingValue=this.Facingvalue;
    }

    handlePlace(event){//place robot in position
        if(isNaN(this.xvalue) || isNaN(this.yvalue)){
            this.showToastMessage('Input for x and y should be number','error');
        }else if(this.xvalue<0 || this.yvalue<0){
            this.showToastMessage('Negative values not allowed','error');
        }else{
            this.placed='true';
            this.showToastMessage('successfully placed','success');
        }
    }
    // Move robot in placed direction by one unit
    handleMove(event){
        if(this.placed=='true'){ // Check if robot is properly placed
        handleMove({x:this.xvalue,y:this.yvalue,Facing:this.Facingvalue})// Make apex call to move robot by one unit
            .then(result=>{
                //console.log('-->my'+result.x);
                if(result.Error==null){
                    this.xvalue=result.x;//new coordinate of x
                    this.yvalue=result.y;//new coordinate of y
                }else{
                    //alert(result.Error);
                    this.showToastMessage(result.Error,'error');
                }
                
            })
            .catch(error => {
                this.error = error;
            });
        }else{
            this.showToastMessage('place robot in correct position like: East,North etc..','error');//show error msg
        }    
    }

    handleLeft(event){// turn robot to left
        if(this.placed=='true'){// check for proper position
            if(this.Facingvalue=='East'){
                this.Facingvalue='North';
            }
            else if(this.Facingvalue=='North'){
                this.Facingvalue='West';
            }
            else if(this.Facingvalue=='West'){
                this.Facingvalue='South';
            }
            else if(this.Facingvalue=='South'){
                this.Facingvalue='East';
            }
        }else{
            this.showToastMessage('place robot in correct position like: East,North etc..','error');
        } 
    }

    handleRight(event){//turn robot right
        if(this.placed=='true'){
            if(this.Facingvalue=='East')
                this.Facingvalue='South';
            else if(this.Facingvalue=='North')
                this.Facingvalue='East';
            else if(this.Facingvalue=='West')
                this.Facingvalue='North';
            else if(this.Facingvalue=='South')
                this.Facingvalue='West';
        }else{
            this.showToastMessage('place robot in correct position like: East,North etc..','error');
        } 
    }

    handleReport(event){// Display current position
        this.showToastMessage('Current Position:'+this.xvalue +','+this.yvalue+','+this.Facingvalue,'info');//show error msg
    }
    
    changeXvalue(event){//set x coordinate value
        this.xvalue=event.target.value;
    }

    changeYvalue(event){//set y coordinate value
        this.yvalue=event.target.value;
    }

    showToastMessage(errorMessage,variantType){//reusable method for toast messages
        const evt = new ShowToastEvent({
            title: 'Robot Info',
            message:errorMessage,
            variant:variantType,
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }
}